#!/usr/bin/env bash
pip3 install --user z3-solver